ABDUL LEGEND JALLABIYA LUXURY & CAP — WEBSITE PACKAGE

Files:
- index.html: working, mobile-friendly website.
- assets/design-preview.png: visual concept preview (if included).

Before publishing:
1. Confirm or edit the sample prices shown on the website.
2. Replace product illustrations with real photos of your tailoring work when available.
3. WhatsApp order contact is set to 2348080686284.
4. This static website sends order enquiries to WhatsApp; online payment checkout is not yet integrated.

To publish:
- Create an account with a static host such as Netlify.
- Upload/deploy index.html (and the assets folder if desired).
- Test the website and WhatsApp order form on your phone.
- Connect a custom domain and payment checkout later if desired.
